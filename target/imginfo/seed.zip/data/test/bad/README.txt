This directory contains numerous image files whose contents correspond
to invalid (i.e., corrupt) image data.  These files are useful for
testing purposes.
