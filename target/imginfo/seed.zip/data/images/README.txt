This directory contains numerous test images, stored in various formats.

goldenears
goldenears_gray
	A picture taken at Golden Ears Provincial Park,
	located near Maple Ridge, BC, Canada.

stawamuschief
stawamuschief_gray
	A picture taken at Stawamus Chief Provincial Park,
	located close to Squamish, BC, Canada.
